from .models import Task
from django.contrib import admin
# Register your models here.
admin.site.register(Task)
